import pygame
import toolbox

from hitbox import Hitbox

class Fighter(pygame.sprite.Sprite):
    def __init__(self, spawn_coords, number):
        pygame.sprite.Sprite.__init__(self, self.containers)
        self.spawn_coords = spawn_coords
        self.number = number
        self.image = pygame.image.load("../assets/Monkey/Monkey_idle_1.png")
        self.rect = self.image.get_rect(midbottom=self.spawn_coords)
        #self.keys = keys

        self.anim_state = "idle"
        self.anim_state_changed = False
        
        self.run_speed = 8
        self.x_knockback_slowdown = 0.5
        self.x_move = 0
        self.x_flipped = False
        self.x_knockback_momentum = 0

        self.gravity = 1.6
        self.max_fall_speed = 30
        self.jump_speed = -24
        self.max_jumps = 3
        self.fast_fall_speed = 0.9

        self.y_move = 0
        self.jumps_left = self.max_jumps
        self.grounded = False
        self.down_pressed = False
        

        self.damage_percentage = 0

        self.jump_key = toolbox.keyDownListener()
        self.attack1_key = toolbox.keyDownListener()
        self.attack2_key = toolbox.keyDownListener()
        self.attack3_key = toolbox.keyDownListener()

    def HandleInput(self, keys):
        self.jump_key.update(keys[pygame.K_UP])
        self.attack1_key.update(keys[pygame.K_q])
        self.attack2_key.update(keys[pygame.K_w])
        self.attack3_key.update(keys[pygame.K_e])

        self.anim_state_changed = False
        

        #try:
            #result = list(keys[0].keys())
            #keys = self.keys.transform(result)
            
        if keys[pygame.K_LEFT]:
            if not self.x_flipped:
                self.x_flipped = True
            else:
                self.x_move = -self.run_speed
                if self.grounded and self.anim_state != "run":
                    self.anim_state = "run"
                    self.anim_state_changed = True
        if keys[pygame.K_RIGHT]:
            if self.x_flipped:
                self.x_flipped = False
            else:
                self.x_move = self.run_speed
                if self.grounded and self.anim_state != "run":
                    self.anim_state = "run"
                    self.anim_state_changed = True
        if not keys[pygame.K_LEFT] and not keys[pygame.K_RIGHT]:
            self.x_move = 0
            should_idle = (self.anim_state != "idle"
                           and self.anim_state != "attack1"
                           and self.anim_state != "attack2"
                           and self.anim_state != "attack3"
                           and self.grounded)
            if should_idle:
                self.anim_state = "idle"
                self.anim_state_changed = True

        if keys[pygame.K_DOWN]:
            self.down_pressed = True
            self.y_move += self.fast_fall_speed
        else:
            self.down_pressed = False
                
        if self.jump_key.down:
            if self.jumps_left > 0:
                self.y_move = self.jump_speed
                self.jumps_left -= 1
                self.anim_state = "jump"
                self.anim_state_changed = True

        if self.attack1_key.down:
            self.doAttack1()
            self.anim_state_changed = True
            self.anim_state = "attack1"
        elif self.attack2_key.down:
            self.doAttack2()
            self.anim_state_changed = True
            self.anim_state = "attack2"
        elif self.attack3_key.down:
            self.doAttack3()
            self.anim_state_changed = True
            self.anim_state = "attack3"

    def doAttack1(self):
        size = (20,15)
        if self.x_flipped:
            x, y = self.rect.topleft
        else:
            x, y = self.rect.topright
        y +=35
        damage = 0.03
        knockback = (2,15)
        duration = 2
        Hitbox(self.number, (x,y), size, damage, knockback, duration, self.x_flipped)

    def doAttack2(self):
        size = (18,18)
        if self.x_flipped:
            x, y = self.rect.topleft
        else:
            x, y = self.rect.topright
        y += 60
        damage = 0.02
        knockback = (15,2)
        duration = 2
        Hitbox(self.number, (x,y), size, damage, knockback, duration, self.x_flipped)

    def doAttack3(self):
        size = (24,12)
        if self.x_flipped:
            x, y = self.rect.topleft
        else:
            x, y = self.rect.topright
        y += 90
        damage = 0.05
        knockback = (6,7)
        duration = 2
        Hitbox(self.number, (x,y), size, damage, knockback, duration, self.x_flipped)

    
    def GetHit(self, damage, knockback, flipped):
        self.damage_percentage += damage
        
        self.y_move -= knockback[1] * self.damage_percentage

        if flipped:
            self.x_knockback_momentum -= knockback[0] * self.damage_percentage
        else:
            self.x_knockback_momentum += knockback[0] * self.damage_percentage
            print("I got hit!")

        #except:
            #print("An exception has occured")
            #print(keys)
            
    def update(self, platforms, hitboxes):
        self.y_move += self.gravity
        if self.y_move > self.max_fall_speed:
            self.y_move = self.max_fall_speed

        if self.x_knockback_momentum > 0:
            self.x_knockback_momentum -= self.x_knockback_slowdown
        else:
            self.x_knockback_momentum += self.x_knockback_slowdown
        if abs(self.x_knockback_momentum) <= self.x_knockback_slowdown:
            self.x_knockback_momentum = 0

        
        self.rect.x += self.x_move + self.x_knockback_momentum
        for platform in platforms:
            if self.rect.colliderect(platform.rect) and not platform.jump_through:
                if self.rect.top < platform.rect.top:
                    self.rect.bottom = platform.rect.top
                else:
                    if self.x_move + self.x_knockback_momentum > 0:
                        self.rect.right = platform.rect.left
                        self.x_knockback_momentum = 0
                    else:
                        self.rect.left = platform.rect.right
                        self.x_knockback_momentum = 0
                        
        self.rect.y += self.y_move
        self.grounded = False
        for platform in platforms:
            if self.rect.colliderect(platform.rect):
                if self.y_move >= 0:
                    should_drop_through = (self.down_pressed and platform.jump_through)
                    if not should_drop_through:
                        if self.rect.top < platform.rect.top:
                            self.rect.bottom = platform.rect.top
                            self.y_move = 0
                            self.jumps_left = self.max_jumps
                            self.grounded = True
                else:
                    if not platform.jump_through:
                        self.rect.top = platform.rect.bottom
                        self.y_move = 0

        for hitbox in hitboxes:
            if self.rect.colliderect(hitbox.rect):
                if self.number != hitbox.creator_num:
                    self.GetHit(hitbox.damage, hitbox.knockback, hitbox.flipped)

class Monkey(Fighter):
    def __init__(self, spawn_coords, number):
        Fighter.__init__(self, spawn_coords, number)
        self.name = "Monkey"

class Goblin(Fighter):
    def __init__(self, spawn_coords, number):
        Fighter.__init__(self, spawn_coords, number)
        self.name = "Goblin"
