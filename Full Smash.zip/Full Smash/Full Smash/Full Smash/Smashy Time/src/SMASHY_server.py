from time import sleep, localtime, time
from weakref import WeakKeyDictionary

from PodSixNet.Server import Server
from PodSixNet.Channel import Channel

import socket
import pygame
import toolbox

from lobbyAvatar import LobbyAvatar
from fighter import *
from platforms import Platform
from hitbox import Hitbox

class ClientChannel(Channel):
    """
    This is the server representation of a single connected client.
    """
    def __init__(self, *args, **kwargs):
        Channel.__init__(self, *args, **kwargs)
        self.number = 0
        self.lobby_avatar = None
        self.color = None
        self.fighter = None
	
    def Close(self):
        self._server.DelPlayer(self)

    def isValid(self):
        return self.number >= 1 and self.number <= 5
         
    #####################################
    ### Server-side Network functions ###
    #####################################

    """
    Each one of these "Network_" functions defines a command
    that the client will ask the server to do.
    """

    def Network_hi(self, data):
        """
        Network_hi just prints a message
        """
        print("OMG a client just said hi to me")

    """
    def Network_keys(self, data):
        keys = pygame.key.ScancodeWrapper(data["keys"])
        
        if self.lobby_avatar:
            #self.lobby_avatar.HandleInput(data["keys"])
            self.lobby_avatar.HandleInput(keys)
    """

    def Network_keys(self,data):

        if self.fighter:
            self.fighter.HandleInput(data["keys"])
            
        elif self.lobby_avatar:
            self.lobby_avatar.HandleInput(data["keys"])
        
class MyGameServer(Server):
    channelClass = ClientChannel
	
    def __init__(self, *args, **kwargs):
        """
        Server constructor function. This is the code that runs once
        when the server is made.
        """
        Server.__init__(self, *args, **kwargs)
        self.clock = pygame.time.Clock()
        self.players = WeakKeyDictionary()

        self.game_width = 1000
        self.game_height = 650

        
        self.LOBBY_COORDS = [None, (300, 200), (400, 200), (500, 200), (600, 200), (700, 200)]
        self.COLORS = [None, (0,0,255), (255,0,0), (0,255,0), (255,255,0), (0,255,255)]
        self.SPAWN_COORDS = [None, (300, 200), (400, 200), (500, 200), (600, 200), (700, 200)]

        self.fighters_group = pygame.sprite.Group()
        Fighter.containers = self.fighters_group
        self.platforms_group = pygame.sprite.Group()
        Platform.containers = self.platforms_group
        self.hitboxes_group = pygame.sprite.Group()
        Hitbox.containers = self.hitboxes_group
        
        self.in_lobby = True
        self.game_over = False

        self.game_over_time = 0
        self.game_over_duration = 13

        self.winner_num = 0
        
        print('Server launched')

	
    def Connected(self, player, addr):
        """
        Connected function runs every time a client
        connects to the server.
        """
        self.players[player] = True
        self.AssignNumber(player)
        if player.isValid():
            self.AssignLobbyAvatar(player)
            self.AssignColor(player)
            print("Player " + str(player.number) + " joined from " + str(addr))
            self.PrintPlayers()
        else:
            player.Send({"action": "disconnected"})
            print("Extra player kicked")

    def AssignNumber(self, player):
        """
        Assign new numbers to each player
        """
        if self.in_lobby:
            numbers_in_use = [p.number for p in self.players]
            new_number = 1
            found_it = False
            while not found_it:
                if new_number in numbers_in_use:
                    new_number += 1
                else:
                    found_it = True
            player.number = new_number
        else:
            player.number = -1

    def AssignLobbyAvatar(self, player):
        player.lobby_avatar = LobbyAvatar(self.LOBBY_COORDS[player.number])

    def AssignColor(self, player):
        player.color = self.COLORS[player.number]

    def AssignFighter(self, player):
        fighter_type = player.lobby_avatar.fighter_type
        if fighter_type == 0:
            player.fighter = Monkey(self.SPAWN_COORDS[player.number], player.number)
        elif fighter_type == 1:
            player.fighter = Goblin(self.SPAWN_COORDS[player.number], player.number)
        elif fighter_type == 2:
            player.fighter = Ninja(self.SPAWN_COORDS[player.number], player.number)
            
    def CoordsForPercentage(self, number):
        x_offset = 100
        num_of_fighters = len(self.fighters_group)
        starting_point = self.game_width/2 - (x_offset/2 * (num_of_fighters-1))

        x = starting_point + x_offset*(number-1)
        y = 620
        return (x,y)

    def StartGame(self):
        self.in_lobby = False
        for p in self.players:
            if p.isValid():
                self.AssignFighter(p)
                self.SendToAll({"action": "setup_fighter",
                                "number": p.number,
                                "fighter_name": p.fighter.name})

        self.MakePlatforms()

    def GameOver(self, winner_num):
        self.game_over = True
        self.winner_num = winner_num
        self.game_over_time = time()

        
    def BackToLobby(self):
        self.fighters_group.empty()
        self.platforms_group.empty()
        self.hitboxes_group.empty()
        for p in self.players:
            if p.isValid():
                p.lobby_avatar.ready = False
                p.fighter = None
        self.in_lobby = True
        self.game_over = False
    
    def MakePlatforms(self):
        Platform(0, (0, 530), (1000,150), 0)
        Platform(1, (0,300), (50,200), 2)
        Platform(2, (730,200), (200,100), 1, jump_through=True)

        for platform in self.platforms_group:
            self.SendToAll({"action": "setup_platforms",
                            "size": platform.size,
                            "number": platform.number,
                            "type": platform.type})

        
    def DelPlayer(self, player):
        """
        DelPlayer function removes a player from the server's list of players.
        In other words, 'player' gets kicked out.
        """
        del(self.players[player])
        print("Deleting Player" + str(player.addr))
        self.PrintPlayers()

	
    def PrintPlayers(self):
        """
        PrintPlayers prints the number of each connected player.
        """
        print("players: ", [p.number for p in self.players])

        
    def SendToAll(self, data):
        """
        SendToAll sends 'data' to each connected player.
        """
        for p in self.players:
            p.Send(data)
  

    def Update(self):
        """
        Server Update function. This is the function that runs
        over and over again.
        """
        self.Pump()

        self.fighters_group.update(self.platforms_group, self.hitboxes_group)
        self.hitboxes_group.update()

        self.SendToAll({"action": "draw_background"})
        
        if self.in_lobby:
            all_ready = True
            for p in self.players:
                if p.isValid():
                    self.SendToAll({"action": "draw_avatar",
                                    "coords": p.lobby_avatar.coords,
                                    "ready": p.lobby_avatar.ready,
                                    "number": p.number,
                                    "color": p.color,
                                    "fighter_type": p.lobby_avatar.fighter_type})
                    if not p.lobby_avatar.ready:
                        all_ready = False
            if all_ready and len(self.players) >= 1:
                self.StartGame()

        elif self.game_over:
            reset_time = self.game_over_time + self.game_over_duration
            time_left = reset_time - time()
            if time_left > 0:
                self.SendToAll({"action": "draw_victory",
                                "number": self.winner_num,
                                "color": self.COLORS[self.winner_num],
                                "time_left": time_left})
            else:
                self.BackToLobby()
            
        else:
            for platform in self.platforms_group:
                self.SendToAll({"action": "draw_platform",
                                "coords": platform.coords,
                                "size": platform.size,
                                "number": platform.number})

            alive_players = []     
            for p in self.players:
                if p.isValid():
                    if not p.fighter.defeated:
                        p.fighter.checkIfOffScreen(self.game_width, self.game_height)
                        alive_players.append(p)
                        if p.fighter.anim_state_changed:
                            self.SendToAll({"action": "change_fighter_state",
                                            "number": p.number,
                                            "state": p.fighter.anim_state})
                        if p.fighter.sfx_to_play:
                            self.SendToAll({"action": "play_sfx",
                                            "name": p.fighter.sfx_to_play})
                        self.SendToAll({"action": "draw_fighter",
                                        "coords": p.fighter.rect.midbottom,
                                        "number": p.number,
                                        "color": p.color,
                                        "flipped": p.fighter.x_flipped})
                        self.SendToAll({"action": "draw_percentage",
                                        "coords":  self.CoordsForPercentage(p.number),
                                        "percentage": p.fighter.damage_percentage,
                                        "color": p.color,
                                        "lives": p.fighter.lives,
                                        "number": p.number})
            if len(alive_players) == 1:
                self.GameOver(alive_players[0].number)
            elif len(alive_players) == 0:
                self.BackToLobby()
            #for hitbox in self.hitboxes_group:
             #   self.SendToAll({"action": "draw_hitbox",
              #                  "coords": hitbox.rect.topleft,
               #                 "size": hitbox.size})
            
        self.SendToAll({"action": "flip"})
        
        self.clock.tick(30)
        

ip = toolbox.getMyIP()
port = 5555
server = MyGameServer(localaddr=(ip, port))
print("host ip: " + ip)

"""This is the loop that keeps going until the server is killed"""
while True:
    server.Update()



    
