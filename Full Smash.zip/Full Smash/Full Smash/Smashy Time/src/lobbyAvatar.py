import pygame
import toolbox

class LobbyAvatar():
    def __init__(self, coords):
        self.coords = coords
        self.ready = False

        self.ready_key = toolbox.keyDownListener()
        self.keys = toolbox.keys_transform()
    """
    def HandleInput(self, keys):
        keys = self.keys.transform(keys)
        self.ready_key.update(keys[pygame.K_SPACE])
        print("Checking ready key...")
        if self.ready_key.down:
            print("Ready key pressed!")
            self.ready = not self.ready 
    """

    def HandleInput(self, keys):
        self.ready_key.update(keys[pygame.K_SPACE])
        #print("HandleInput called...")
        if self.ready_key.down:
            self.ready = not self.ready
            print("Flipping!")
