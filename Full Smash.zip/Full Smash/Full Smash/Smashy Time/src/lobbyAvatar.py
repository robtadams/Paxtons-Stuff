import pygame
import toolbox

class LobbyAvatar():
    def __init__(self, coords):
        self.coords = coords
        self.ready = False

        self.fighter_type = 0
        self.num_of_fighters = 3 #change number when adding new fighter
        self.highest_index = self.num_of_fighters - 1

        self.ready_key = toolbox.keyDownListener()
        self.next_key = toolbox.keyDownListener()
        self.prev_key = toolbox.keyDownListener()
        self.keys = toolbox.keys_transform()
    """
    def HandleInput(self, keys):
        keys = self.keys.transform(keys)
        self.ready_key.update(keys[pygame.K_SPACE])
        print("Checking ready key...")
        if self.ready_key.down:
            print("Ready key pressed!")
            self.ready = not self.ready 
    """

    def HandleInput(self, keys):
        self.ready_key.update(keys[pygame.K_SPACE])
        self.next_key.update(keys[pygame.K_RIGHT])
        self.prev_key.update(keys[pygame.K_LEFT])
        
        if self.ready_key.down:
            self.ready = not self.ready
            print("Flipping!")
        if self.next_key.down:
            self.nextFighter()
        if self.prev_key.down:
            self.prevFighter()

    def nextFighter(self):
        self.fighter_type += 1
        if self.fighter_type > self.highest_index:
            self.fighter_type = 0

    def prevFighter(self):
        self.fighter_type -= 1
        if self.fighter_type < 0:
            self.fighter_type = self.highest_index
