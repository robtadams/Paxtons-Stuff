import pygame

class Hitbox(pygame.sprite.Sprite):
    def __init__(self, creator_num, coords, size, damage, knockback, duration, flipped):
        pygame.sprite.Sprite.__init__(self, self.containers)
        self.creator_num = creator_num
        self.size = size
        self.damage = damage
        self.knockback = knockback
        self.duration = duration
        self.flipped = flipped

        self.rect = pygame.Rect(coords, self.size)
        if self.flipped:
            self.rect.right = self.rect.left

    def update(self):
        if self.duration <= 0:
            self.kill()
        self.duration -= 1
