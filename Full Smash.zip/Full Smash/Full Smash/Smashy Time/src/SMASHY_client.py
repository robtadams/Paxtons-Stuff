import pygame
import toolbox
import random
from PodSixNet.Connection import ConnectionListener, connection
from time import sleep
import animation

"""
Warning Suppresion for: libpng warning: iCCP: known incorrect sRGB profile
"""
#import warnings
#warnings.filterwarnings("ignore")



running = True


class MyGameClient(ConnectionListener):
    def __init__(self, host, port):
        """
        Client constructor function. This is the code that runs once
        when a new client is made.
        """
        ConnectionListener.__init__(self)
        
        # Start the game
        pygame.init()
        pygame.mixer.pre_init(buffer=1024)
        game_width = 1000
        game_height = 650
        self.screen = pygame.display.set_mode((game_width, game_height))
        self.clock = pygame.time.Clock()

        self.stuffToDrawNow = []
        self.stuffToDrawNext = []
        
        self.background = pygame.image.load("../assets/bg_lava_new.png")
        #self.avatar_image = pygame.image.load("../assets/Monkey/Monkey_jump_2.png")
        self.avatar_images = [ pygame.image.load("../assets/Monkey/Monkey_idle_1.png"),
                               pygame.image.load("../assets/Goblin/Goblin_idle_1.png"),
                               pygame.image.load("../assets/Ninja/Ninja_idle_1.png") ]
        #self.fighter_image = pygame.image.load("../assets/Monkey/Monkey_idle_1.png")
        self.platform_images_base = [ pygame.image.load("../assets/Old Images/platform_lava1.png"),
                                      pygame.image.load("../assets/Old Images/platform_lava2.png"),
                                      pygame.image.load("../assets/Old Images/platform_lava_wall1.png") ]
        self.platform_images = {}
        self.animation_managers = {}

        self.medium_font = pygame.font.SysFont("default", 40)
        self.small_font = pygame.font.SysFont("defualt", 20)

        self.ready_text = self.small_font.render("Ready!", True, (0, 255, 0))
        self.not_ready_text = self.small_font.render("Not Ready", True, (255, 0, 0))

        self.connected = False

        self.Connect((host, port))


    def update(self):
        """
        Client update function. This is the function that runs over and
        over again, once every frame of the game.
        """
        connection.Pump()
        self.Pump()

        # Set running to False if the player clicks the X or presses esc
        global running
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                running = False

        #connection.Send({"action": "keys", "keys": pygame.key.get_pressed()})

        """*** START EDIT ***"""
        # DEXTER BEGIN
        keystate = pygame.key.get_pressed()

        key_data = {
            pygame.K_SPACE: keystate[pygame.K_SPACE],
            pygame.K_LEFT: keystate[pygame.K_LEFT],
            pygame.K_RIGHT: keystate[pygame.K_RIGHT],
            pygame.K_UP: keystate[pygame.K_UP],
            pygame.K_DOWN: keystate[pygame.K_DOWN],
            pygame.K_q: keystate[pygame.K_q],
            pygame.K_w: keystate[pygame.K_w],
            pygame.K_e: keystate[pygame.K_e],
            pygame.K_DOWN: keystate[pygame.K_DOWN]
            # TODO - Add more as needed
        }

        connection.Send({"action": "keys", "keys": key_data})

        #connection.Send({"action": "keys", "keys": key_list})
        # DEXTER END
        """*** END EDIT ***"""

        
        for thing in self.stuffToDrawNow:
            self.screen.blit(thing[0], thing[1])
            
            
        # Tell pygame to update the screen
        pygame.display.flip()
        self.clock.tick(30)
        pygame.display.set_caption("ULTIMATE SMASH! fps: " + str(self.clock.get_fps()))


    def ShutDown(self):
        """
        Client ShutDown function. Disconnects and closes the game.
        """
        self.connected = False
        connection.Close()
        pygame.quit()
        exit()
        
                
    #####################################
    ### Client-side Network functions ###
    #####################################
    """
    Each one of these "Network_" functions defines a command
    that the server will tell you (the client) to do.
    """

    def Network_flip(self, data):
        """
        move all stuff from stufftodrawnext into stufftodrawnow
        """
        self.stuffToDrawNow.clear()
        for thing in self.stuffToDrawNext:
            self.stuffToDrawNow.append(thing)
        self.stuffToDrawNext.clear()

    def Network_setup_platforms(self, data):
        image = self.platform_images_base[data["type"]]
        squished_image = pygame.transform.scale(image, data["size"])
        self.platform_images[data["number"]] = squished_image

    def Network_setup_fighter(self, data):
        new_manager = getattr(animation, data["fighter_name"]+"AnimationManager")()
        self.animation_managers[data["number"]] = new_manager

    def Network_draw_background(self, data):
        self.stuffToDrawNext.append([self.background, (0,0)])

    def Network_draw_avatar(self, data):
        avatar_image = self.avatar_images[data["fighter_type"]]
        avatar_rect = avatar_image.get_rect(center=data["coords"])
        self.stuffToDrawNext.append([avatar_image, avatar_rect])

        if data["ready"]:
            text_to_draw = self.ready_text
        else:
            text_to_draw = self.not_ready_text
        text_rect = text_to_draw.get_rect(midtop = avatar_rect.midbottom)
        text_rect.y += 4
        self.stuffToDrawNext.append([text_to_draw, text_rect])

        num_text = self.medium_font.render(str(data["number"]), True, data["color"])
        text_rect = num_text.get_rect(midbottom=avatar_rect.midtop)
        text_rect.y -= 4
        self.stuffToDrawNext.append([num_text, text_rect])

    def Network_draw_fighter(self, data):
        image_to_draw = self.animation_managers[data["number"]].getImage(flipped=data["flipped"])
        image_rect = self.animation_managers[data["number"]].getRect(data["flipped"], data["coords"])
        self.stuffToDrawNext.append([image_to_draw, image_rect])
        
        num_text = self.medium_font.render(str(data["number"]), True, data["color"])
        text_rect = num_text.get_rect(midbottom=image_rect.midtop)
        text_rect.y -= 4
        self.stuffToDrawNext.append([num_text, text_rect])

    def Network_draw_platform(self, data):
        #surface = pygame.Surface(data["size"])
        #surface.fill((50,0,75))
        #self.stuffToDrawNext.append([surface, data["coords"]])
        x, y = data["coords"]
        y -= 30
        self.stuffToDrawNext.append([self.platform_images[data["number"]], (x,y)])

    def Network_draw_hitbox(self, data):
        surface = pygame.Surface(data["size"])
        surface.fill((50,0,75))
        self.stuffToDrawNext.append([surface, data["coords"]])

    def Network_draw_percentage(self, data):
        percentage_string = str(int(data["percentage"]*100)) + "%"
        text = self.medium_font.render(percentage_string, True, data["color"])
        text_rect = text.get_rect(midbottom=data["coords"])
        self.stuffToDrawNext.append([text, text_rect])

    def Network_change_fighter_state(self, data):
        self.animation_managers[data["number"]].ChangeState(data["state"])
        
    def Network_connected(self, data):
        """
        Network_connected runs when you successfully connect to the server
        """
        self.connected = True
        print("Connection succesful!")
        #connection.Send({"action": "hi"})
    
    def Network_error(self, data):
        """ 
        Network_error runs when there is a server error
        """
        print('error:', data['error'][1])
        self.ShutDown()
    
    def Network_disconnected(self, data):
        """
        Network_disconnected runs when you disconnect from the server
        """
        print('Server disconnected')
        self.ShutDown()

#change ip if you are on a different computer
#50.222.25.147
#50.222.25.138
ip = "50.222.25.153" #input("Please enter the host's IP address: ")
port = 5555
thisClient = MyGameClient(ip, port)

"""This is the loop that keeps going until the game is closed"""
while running:
    thisClient.update()
    
thisClient.ShutDown()
