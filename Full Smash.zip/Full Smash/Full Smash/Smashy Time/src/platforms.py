import pygame

class Platform(pygame.sprite.Sprite):
    def __init__(self, number, coords, size, image_type, jump_through=False):
        pygame.sprite.Sprite.__init__(self, self.containers)
        self.number = number
        self.coords = coords
        self.size = size
        self.type = image_type
        self.rect = pygame.Rect(self.coords, self.size)
        self.jump_through = jump_through
